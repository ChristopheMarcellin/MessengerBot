"# Force Git to track this folder" 
